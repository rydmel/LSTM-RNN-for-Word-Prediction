from nltk.tokenize import RegexpTokenizer
import time
import torch
import torch.nn as nn
import torch.optim as optim
import random
import math


from Encode_LSTM import LSTMEncoder
from Decode_LSTM import LSTMDecoder
from RNN import FinalRNN
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def create_dicts():
    lines = open("bobsue.voc.txt", "rb").readlines()
    voc_dict = {}
    voc_list = []

    for line in lines:
        word = line.decode('utf-8', errors='replace').strip()
        voc_dict[word] = len(voc_dict)
        voc_list.append(word)

    return voc_dict, voc_list

# Convert words to dictionary of vectors. "file" contains words
# vec_length is desired vector length
def words_to_vec_rand(file,vec_length):
    with open(file, encoding="utf8" ) as f:
       content = f.readlines()
    word_dict = {}
    for word in content:
        word = word.strip('\n\r')
        embedding = np.random.rand(vec_length)
        word_dict[word] = embedding
    # print ("Done.",len(word_dict)," words loaded!")  # For debugging
    return word_dict


# NOTE THAT glove words are all LOWERCASE, so word MUST BE CONVERTED
# TO LOWERCASE (using word.lower()) before lookup in the glove dictionary
def words_to_vec_glove(glovefile):
    print("Loading Glove Model")
    f = open(glovefile,encoding="utf8")
    word_dict = {}
    for line in f:
        splitLine = line.split()
        word = splitLine[0]
        embedding = np.array([float(val) for val in splitLine[1:]])
        word_dict[word] = embedding
    print("Done.",len(word_dict)," words loaded!")
    return word_dict



def load_sentences(filename):
    lines = open(filename, "rb").readlines()
    sentences1 = []
    sentences2 = []
    for line in lines:
        sentences = line.decode('utf-8', errors='replace').split('\t')
        sentences1.append(sentences[0])
        sentences2.append(sentences[1].strip('\n'))
    return sentences1, sentences2

def tokenize_sentence(sent):
    tokenizer = RegexpTokenizer('\w+|\$[\d\.]+|\S+')
    t = tokenizer.tokenize(sent)
    return t

def to_dictList(sent1, sent2):
    dict ={}
    dl = []
    for i in range(len(sent1)):
        dict['x'] = tokenize_sentence(sent1[i])
        dict['y'] = tokenize_sentence(sent2[i])
        dl.append(dict)
    return dl

def file_to_dlist(filename):
    a,b = load_sentences(filename)
    f = to_dictList(a, b)
    return f

def train(model, iter, optimizer, criterion, clip):
    model.train()
    epoch_loss = 0

    for i, batch in enumerate(iter):
        x = batch.x
        y = batch.y
        optimizer.zero_grad()
        output = model(x, y)
        output = output[1:].view(-1, output.shape[-1])
        y = y[1:].view(-1)

        loss = criterion(output, y)

        loss.backward()

        torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
        optimizer.step()
        epoch_loss += loss.item()

    return (epoch_loss/len(iter))


def eval_model(model, iter, criterion):
    model.eval()

    epoch_loss = 0

    with torch.no_grad():
        for i, batch in enumerate(iter):
            x = batch.x
            y = batch.y
            output = model(x, y, 0)
            output = output[1:].view(-1, output.shape[-1])
            y = y[1:].view(-1)

            loss = criterion(output, y)
            epoch_loss += loss.item()

    return epoch_loss/len(iter)

def epoch_time(t0, t_final):
    elapsed_time = t_final - t0
    elapsed_mins = int(elapsed_time/60)
    elapsed_secs = int(elapsed_time - (elapsed_mins * 60))
    return elapsed_mins,elapsed_secs

train_data = file_to_dlist('bobsue.seq2seq.train.tsv')
valid_data = file_to_dlist('bobsue.seq2seq.dev.tsv')
test_data = file_to_dlist('bobsue.seq2seq.test.tsv')

bsize = 50

train_iter = getBatch(train_data)
valid_iter = getBatch(valid_data)
test_iter = getBatch(test_data)

inp_dim = 1498  #len of vocab
out_dim = 1498 #len of vocab
Encoder_emb_dim = 200
Decoder_emb_dim = 200
hidden_dim = 200
layer_size = 1
encoder_dropout = 0.25
decoder_dropout = 0.25

Enc = LSTMEncoder(inp_dim, Encoder_emb_dim, hidden_dim, layer_size, encoder_dropout)
Dec = LSTMDecoder(out_dim, Decoder_emb_dim, hidden_dim, layer_size, decoder_dropout)

model = FinalRNN(Enc, Dec, device).to(device)

optimizer = optim.SGD(model.parameters())
criterion = nn.MSELoss()





num_epochs = 6
c = 1 

for epoch in range(num_epochs):
    t0 = time.time()
    training_loss = train(model, train_iter, optimizer, criterion, c)
    validation_loss = eval_model(model, valid_iter, criterion)
    t_final = time.time()
    minutes, secs = epoch_time(t0, t_final)

    print(f'epoch: {epoch} , time: {minutes}min {secs}sec')
    print(f'\t training loss: {training_loss:.3f}')
    print(f'\t validation loss: {validation_loss:.3f}')